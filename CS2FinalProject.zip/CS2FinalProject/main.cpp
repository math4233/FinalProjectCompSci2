#include <iostream>
#include "FIelds.h"
using namespace std;
int main()
{
    //initializes a Fields object, which when calling beginProcess(), will start the program
    Fields bruh;
    //begins the program
    bruh.beginProcess();
    return 0;
}
